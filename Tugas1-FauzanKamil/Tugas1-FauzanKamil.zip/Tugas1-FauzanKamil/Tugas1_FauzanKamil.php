<!DOCTYPE html>
<html>
<head>
    <title>Pertemuan 1</title>

</head>
<body>
    <h1> VSGA - Junior Web Developer </h1>
    <?php
        echo "Selamat Datang"; 
        echo "<br>";
        echo "Ayo Kita Belajar Junior Web Developer Bersama";
        echo "<br>";
        echo "di BPPTIK Cikarang"
    ?>
</body>
</html>